<div class="navigation" role="navigation">
  <div class="video-bg hidden-sm hidden-xs">
    <video src="videos/video.mp4" muted autoplay loop></video>
  </div>
  <!-- end video-bg -->
  <div class="table">
    <div class="inner">
      <nav>
        <ul>
          <li><a href="/" class="transition">HOME</a></li>
          <li><a href="About" class="transition">ABOUT US</a></li>
          <li><a href="services" class="transition">SERVICES</a></li>
          <li><a href="showcase.html">SHOWCASE</a></li>
          <!-- <li><a href="news.html" class="transition">NEWS</a></li> -->
          <li><a href="contact" class="transition">CONTACT</a></li>
        </ul>
      </nav>
      <span class="copyright">© 2021 Creative X | Mount Lavinia, Sri Lanka</span> </div>
    <!-- end inner --> 
  </div>
  <!-- end table --> 
</div><?php /**PATH F:\Office\Laravel Webs\Createx\resources\views/include/nav.blade.php ENDPATH**/ ?>